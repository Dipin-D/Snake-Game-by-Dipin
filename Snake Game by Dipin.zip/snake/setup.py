import sys
from cx_Freeze import setup, Executable

build_exe_options = {"packages": ["pygame"], "include_files": ["apple.jpg", "background_music.mp3", "background_image.jpg", "score.mp3", "snake.jpg", "game_over.wav"]}

base = None
if sys.platform == "win32":
    base = "Win32GUI"

setup(
    name = "Snake Game",
    version = "1.0",
    description = "My Snake Game",
    options = {"build_exe": build_exe_options},
    executables = [Executable("SNAKE_GAME.py", base=base)]
)
